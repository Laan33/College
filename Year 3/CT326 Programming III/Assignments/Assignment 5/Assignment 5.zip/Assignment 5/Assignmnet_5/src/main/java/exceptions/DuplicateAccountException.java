package exceptions;

public class DuplicateAccountException extends Exception{
}
