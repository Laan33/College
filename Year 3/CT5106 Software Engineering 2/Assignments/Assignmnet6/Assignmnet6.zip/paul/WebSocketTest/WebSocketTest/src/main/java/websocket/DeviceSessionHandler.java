package websocket;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonArray;


import jakarta.enterprise.context.ApplicationScoped;
import jakarta.json.Json;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonObject;
import jakarta.json.JsonObjectBuilder;
import jakarta.websocket.Session;
import model.Comment;

@ApplicationScoped
public class CommentSessionHandler {

    private int commentId = 0;
    private final Set<Session> sessions = new HashSet<>();
    private final Set<Comment> comments = new HashSet<>();
    private final Map<String, String> sessionForums = new HashMap<>();
    private final Map<String, List<String>> forumPosts = new HashMap<>();

    public void addSession(Session session) {
        sessions.add(session);
        for (Comment comment : comments) {
            JsonObject addMessage = createAddMessage(comment);
            sendToSession(session, addMessage);
        }
    }

    public void removeSession(Session session) {
        sessions.remove(session);
    }

    public List<Comment> getComments() {
        return new ArrayList<>(comments);
    }

    public void addComment(Comment comment) {
        comment.setId(commentId);
        comments.add(comment);
        commentId++;
        JsonObject addMessage = createAddMessage(comment);
        sendToAllConnectedSessions(addMessage);
    }

    public void removeComment(int id) {
        Comment comment = getCommentById(id);
        if (comment != null) {
            comments.remove(comment);
            JsonArray removeMessage = Json.createArrayBuilder()
                    .add(Json.createObjectBuilder()
                            .add("action", "remove")
                            .add("id", id)
                    )
                    .build();
            sendToAllConnectedSessions((JsonObject) removeMessage);
        }
    }

    public void toggleComment(int id) {
        Comment comment = getCommentById(id);
        if (comment != null) {
            if ("On".equals(comment.getStatus())) {
                comment.setStatus("Off");
            } else {
                comment.setStatus("On");
            }
            JsonObject updateDevMessage = Json.createObjectBuilder()
                    .add("action", "toggle")
                    .add("id", comment.getId())
                    .add("status", comment.getStatus())
                    .build();
            sendToAllConnectedSessions(updateDevMessage);
        }
    }

    public void addMessage(String forum, String message) {
        List<String> messages = forumPosts.computeIfAbsent(forum, k -> new ArrayList<>());
        messages.add(message);

        JsonObject messageObject = Json.createObjectBuilder()
                .add("action", "message")
                .add("forum", forum)
                .add("message", message)
                .build();

        sendToAllConnectedSessions(messageObject);
    }

    public List<String> getPreviousMessages(String forum) {
        return forumPosts.getOrDefault(forum, new ArrayList<>());
    }

    private Comment getCommentById(int id) {
        for (Comment comment : comments) {
            if (comment.getId() == id) {
                return comment;
            }
        }
        return null;
    }

    private JsonObject createAddMessage(Comment comment) {
        return Json.createObjectBuilder()
                .add("action", "add")
                .add("id", comment.getId())
                .add("name", comment.getName())
                .add("type", comment.getType())
                .add("status", comment.getStatus())
                .add("description", comment.getDescription())
                .build();
    }

    private void sendToAllConnectedSessions(JsonObject message) {
        for (Session session : sessions) {
            sendToSession(session, message);
        }
    }

    private void sendToSession(Session session, JsonObject message) {
        try {
            session.getBasicRemote().sendText(message.toString());
        } catch (IOException ex) {
            sessions.remove(session);
            Logger.getLogger(CommentSessionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
