window.onload = init;
let socket;
let selectedForum;
let username;

function connectWebSocket() {
    socket = new WebSocket("ws://localhost:8080/WebSocketTest/actions");

    socket.onopen = function (event) {
        console.log('WebSocket connection opened:', event);
    };

    socket.onmessage = function (event) {
        onMessage(event);
    };

    socket.onclose = function (event) {
        console.log('WebSocket connection closed:', event);
    };

    socket.onerror = function (error) {
        console.error('WebSocket Error:', error);
    };
}

function joinForum() {
    username = document.getElementById("forum_name").value;

    if (username.trim() === "") {
        alert('Must enter username before joining.');
        return;
    }

    if (selectedForum) {
        // Send a join request to the server
        let joinRequest = {
            action: "join",
            forum: selectedForum,
            username: username
        };
        socket.send(JSON.stringify(joinRequest));

        // Request previous messages for the joined forum
        let requestPreviousMessage = {
            action: "requestPrevious",
            forum: selectedForum
        };
        socket.send(JSON.stringify(requestPreviousMessage));

        // Show the corresponding chat section and hide others
        let chatSections = document.getElementsByClassName("forum-chat");
        for (let i = 0; i < chatSections.length; i++) {
            let section = chatSections[i];
            section.style.display = (section.id === selectedForum.toLowerCase() + "Chat") ? "block" : "none";
        }

        // Hide the forum selection form
        let forumSelectionForm = document.getElementById("addCommentForm");
        forumSelectionForm.style.display = "none";
    } else {
        alert('You must select a forum before trying to join.');
    }
}

function selectForum(forum) {
    selectedForum = forum;
}

function sendMessage(forum) {
    let messageField = document.getElementById(forum + "MessageField");
    let messageToSend = messageField.value;

    if (messageToSend.trim() !== "") {
        // Send the message to the server
        let message = {
            action: "message",
            forum: selectedForum,
            username: username,
            message: messageToSend
        };
        socket.send(JSON.stringify(message));

        // Display the sent message in the corresponding chat box
        let divMessage = document.getElementById(forum + "MessageBox");
        divMessage.innerHTML += "<div><b>" + username + ":</b> " + messageToSend + "</div>";

        // Clear the input field
        messageField.value = "";
    }
}

// Function - handling messages received from the server
function onMessage(event) {
    let message = JSON.parse(event.data);

    if (message.action === "message") {// Handle messages received from the server
        let forum = message.forum.toLowerCase();
        let messageBox = document.getElementById(forum + "MessageBox");
        messageBox.innerHTML += "<div>" + message.message + "</div>";
    } else if (message.action === "previousMessages") { // Previous messages received from the server
        let forum = selectedForum.toLowerCase();
        let messageBox = document.getElementById(forum + "MessageBox");
        let previousMessages = message.messages;
        for (let i = 0; i < previousMessages.length; i++) {
            messageBox.innerHTML += "<div>" + previousMessages[i] + "</div>";
        }
    }
}

function init() {
    connectWebSocket();
}
